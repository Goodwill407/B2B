// update-ret-mfg-po-partial-new.component.ts
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService, CommunicationService } from '@core';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { Location } from '@angular/common';
import { IndianCurrencyPipe } from 'app/custom.pipe';
import { AmountInWordsPipe } from 'app/amount-in-words.pipe';
import Swal from 'sweetalert2';
import { retry, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-update-ret-mfg-po-partial-new',
  standalone: true,
  imports: [
    CommonModule, FormsModule, TableModule, ButtonModule,
    IndianCurrencyPipe, AmountInWordsPipe
  ],
  templateUrl: './update-ret-mfg-po-partial-new.component.html',
  styleUrl: './update-ret-mfg-po-partial-new.component.scss'
})
export class UpdateRetMfgPoPartialNewComponent implements OnInit {
  responseData: any;
  purchaseOrder: any = {};
  confirmedItems: any[] = [];            // Table 1: designs with NO partial rows
  makeToOrderItems: any[] = [];          // Table 2: designs where ANY row is partial

  // Temp/grouping helpers
  groupedConfirmedTemp: any[][] = [];    // Array of arrays, grouped by design
  groupedPartialTemp: any[][] = [];      // Array of arrays, grouped by design

  // Future actions
  removedFromPartial: any[] = [];        // For rows removed from table 2
  finalRemaining: any[] = [];            // Built during Generate action (1 + 2 after removals)

  // UI Properties
  isLoading: boolean = false;
  isIntraState: boolean = false;
  bankDetails: any;

  manufacturerNote: string = '';
  userProfile: any;

  // Optional previous actions (reused for confirmations)
  selectedAction: string | null = null;

  // NEW/UPDATED pieces only – keep the rest of your component as-is

// Optional: toggle if you want to gate the confirm CTA
previewMode = true; // set true after data load if you want explicit preview step

// Add these new fields near other UI properties
showPreview: boolean = false;
previewConfirmedItems: any[] = [];
previewMakeToOrderItems: any[] = [];

  constructor(
    public authService: AuthService,
    private router: Router,
    private communicationService: CommunicationService,
    private route: ActivatedRoute,
    private location: Location
  ) {}

  ngOnInit(): void {
    const poId = this.route.snapshot.paramMap.get('id');
    if (poId) {
      this.loadPOData(poId);
    }
  }

  loadPOData(poId: string) {
    this.isLoading = true;
    const url = `po-retailer-to-manufacture/${poId}`;

    this.authService.get(url).subscribe({
      next: (res: any) => {
        this.responseData = res;
        this.setupPOData(res);
        this.separateItems(res.set);   // regroup by design -> split 1st/2nd tables
        this.updateStateType();
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading PO data:', err);
        this.communicationService.customError1('Failed to load purchase order data');
        this.isLoading = false;
      }
    });
  }

  setupPOData(res: any) {
    this.purchaseOrder = {
      supplierName: res.manufacturer?.companyName || '',
      supplierAddress: `${res.manufacturer?.address}, ${res.manufacturer?.pinCode} - ${res.manufacturer?.state}`,
      supplierContact: res.manufacturer?.mobNumber || '',
      supplierGSTIN: res.manufacturer?.GSTIN || '',
      supplierEmail: res.manufacturer?.email || '',
      supplierPAN: '',

      buyerName: res.retailer?.companyName || '',
      buyerAddress: `${res.retailer?.address}, ${res.retailer?.pinCode} - ${res.retailer?.state}`,
      buyerPhone: res.retailer?.mobNumber || '',
      buyerEmail: res.retailer?.email || '',
      buyerGSTIN: res.retailer?.GSTIN || '',
      buyerPAN: '',

      logoUrl: res.retailer?.logo || '',
      poDate: new Date(res.retailerPoDate).toLocaleDateString(),
      orderNumber: res.poNumber,
      ProductDiscount: parseFloat(res.discount || 0),
      transportDetails: res.transportDetails,
      expDeliveryDate: res.expDeliveryDate,
      partialDeliveryDate: res.partialDeliveryDate
    };

    this.manufacturerNote = res.manufacturerNote || res.note || res.manufacturer?.notes || '';

    if (res.bankDetails) {
      this.bankDetails = res.bankDetails;
    }
  }

  // Group by designNumber, then split:
  // - If ANY row in a design is 'm_partial_delivery' => whole design goes to table 2 (makeToOrderItems)
  // - Otherwise entire design goes to table 1 (confirmedItems)
// Replace your existing separateItems(...) with this version
separateItems(items: any[]) {
  this.confirmedItems = [];
  this.makeToOrderItems = [];
  this.groupedConfirmedTemp = [];
  this.groupedPartialTemp = [];

  // Build map by composite key: designNumber + colourName (fallback to colour)
  const groupMap = new Map<string, any[]>();

  for (const raw of items || []) {
    // Normalize numeric fields
    const quantity = Number(raw.quantity) || 0;
    const availableQuantity = Number(raw.availableQuantity) || 0;
    const price = Number(raw.price) || 0;
    if (price <= 0) continue; // Skip items with invalid price

    // Normalize key parts
    const design = String(raw.designNumber || '').trim().toLowerCase();
    // Prefer colourName; fallback to hex colour; default to 'na'
    const colorNorm = String(raw.colourName || raw.colour || 'na').trim().toLowerCase();

    const normalized = {
      ...raw,
      quantity,             // ordered qty
      availableQuantity,    // available for dispatch
      price                 // numeric
    };

    const key = `${design}||${colorNorm}`;
    if (!groupMap.has(key)) groupMap.set(key, []);
    groupMap.get(key)!.push(normalized);
  }

  // Sorting helper for "Design -> Color -> Size"
  const sorter = (a: any, b: any) => {
    const d = String(a.designNumber || '').localeCompare(String(b.designNumber || ''));
    if (d !== 0) return d;
    const c = String(a.colourName || '').localeCompare(String(b.colourName || ''));
    if (c !== 0) return c;
    return String(a.size || '').localeCompare(String(b.size || ''));
  };

  const confirmedFlat: any[] = [];
  const partialFlat: any[] = [];
  const confirmedGroupArr: any[][] = [];
  const partialGroupArr: any[][] = [];

  // Split by presence of any partial row within the same design+color group
  for (const [, group] of groupMap.entries()) {
    const sortedGroup = [...group].sort(sorter);
    const hasPartial = sortedGroup.some(x => x.status === 'm_partial_delivery');

    if (hasPartial) {
      // Entire design+color group goes to Partial table
      const prepared = sortedGroup.map(item => {
        const remainingQuantity = Math.max(
          (Number(item.quantity) || 0) - (Number(item.availableQuantity) || 0),
          0
        );
        return {
          ...item,
          expectedQty: Number(item.quantity) || 0,
          quantity: Number(item.availableQuantity) || 0, // dispatch qty now
          remainingQuantity                              // used by getGstAmounts(..., true)
        };
      });
      partialGroupArr.push(prepared);
      partialFlat.push(...prepared);
    } else {
      // Entire design+color group goes to Confirmed table
      const prepared = sortedGroup.map(item => ({
        ...item,
        expectedQty: Number(item.quantity) || 0,
        quantity: Number(item.availableQuantity) || 0 // dispatch qty now
      }));
      confirmedGroupArr.push(prepared);
      confirmedFlat.push(...prepared);
    }
  }

  this.groupedConfirmedTemp = confirmedGroupArr;
  this.groupedPartialTemp = partialGroupArr;

  this.confirmedItems = confirmedFlat;
  this.makeToOrderItems = partialFlat;
}


  updateStateType() {
    const buyerState = this.responseData?.retailer?.state?.trim().toLowerCase();
    const supplierState = this.responseData?.manufacturer?.state?.trim().toLowerCase();
    this.isIntraState = !!buyerState && !!supplierState && (buyerState === supplierState);
  }

  // GST Calculation Methods (unchanged api, honors isIntraState)
  getGstAmounts(item: any, useRemainingQty: boolean = false) {
    const quantity = useRemainingQty ?
      (Number(item.remainingQuantity) || 0) :
      (Number(item.quantity) || 0);
    const rate = Number(item.price) || 0;
    const gstRate = Number(item.hsnGst) || 0;

    const taxable = quantity * rate;

    let cgst = 0, sgst = 0, igst = 0;
    if (this.isIntraState) {
      cgst = (taxable * gstRate / 2) / 100;
      sgst = (taxable * gstRate / 2) / 100;
    } else {
      igst = (taxable * gstRate) / 100;
    }

    const totalWithGst = taxable + cgst + sgst + igst;

    return {
      taxable: isNaN(taxable) ? 0 : taxable,
      gstRate: isNaN(gstRate) ? 0 : gstRate,
      cgst: isNaN(cgst) ? 0 : cgst,
      sgst: isNaN(sgst) ? 0 : sgst,
      igst: isNaN(igst) ? 0 : igst,
      totalWithGst: isNaN(totalWithGst) ? 0 : totalWithGst
    };
  }

  // Table Totals (unchanged)
  get confirmedTotals() {
    let totalQty = 0, totalTaxable = 0, totalCGST = 0, totalSGST = 0, totalIGST = 0, totalWithGST = 0;

    for (const item of this.confirmedItems) {
      const gst = this.getGstAmounts(item);
      totalQty += Number(item.quantity) || 0;
      totalTaxable += gst.taxable || 0;
      totalCGST += gst.cgst || 0;
      totalSGST += gst.sgst || 0;
      totalIGST += gst.igst || 0;
      totalWithGST += gst.totalWithGst || 0;
    }

    const discountPercent = Number(this.purchaseOrder.ProductDiscount) || 0;
    const discountAmount = (totalWithGST * discountPercent) / 100;
    const actualGrandTotal = totalWithGST - discountAmount;

    return {
      totalQty: isNaN(totalQty) ? 0 : totalQty,
      totalTaxable: isNaN(totalTaxable) ? 0 : totalTaxable,
      totalCGST: isNaN(totalCGST) ? 0 : totalCGST,
      totalSGST: isNaN(totalSGST) ? 0 : totalSGST,
      totalIGST: isNaN(totalIGST) ? 0 : totalIGST,
      totalWithGST: isNaN(totalWithGST) ? 0 : totalWithGST,
      discountAmount: isNaN(discountAmount) ? 0 : discountAmount,
      actualGrandTotal: isNaN(actualGrandTotal) ? 0 : actualGrandTotal
    };
  }

  get makeToOrderTotals() {
    let totalQty = 0, totalTaxable = 0, totalCGST = 0, totalSGST = 0, totalIGST = 0, totalWithGST = 0;

    for (const item of this.makeToOrderItems) {
      const gst = this.getGstAmounts(item, true); // use remaining
      totalQty += Number(item.remainingQuantity) || 0;
      totalTaxable += gst.taxable || 0;
      totalCGST += gst.cgst || 0;
      totalSGST += gst.sgst || 0;
      totalIGST += gst.igst || 0;
      totalWithGST += gst.totalWithGst || 0;
    }

    const discountPercent = Number(this.purchaseOrder.ProductDiscount) || 0;
    const discountAmount = (totalWithGST * discountPercent) / 100;
    const actualGrandTotal = totalWithGST - discountAmount;

    return {
      totalQty: isNaN(totalQty) ? 0 : totalQty,
      totalTaxable: isNaN(totalTaxable) ? 0 : totalTaxable,
      totalCGST: isNaN(totalCGST) ? 0 : totalCGST,
      totalSGST: isNaN(totalSGST) ? 0 : totalSGST,
      totalIGST: isNaN(totalIGST) ? 0 : totalIGST,
      totalWithGST: isNaN(totalWithGST) ? 0 : totalWithGST,
      discountAmount: isNaN(discountAmount) ? 0 : discountAmount,
      actualGrandTotal: isNaN(actualGrandTotal) ? 0 : actualGrandTotal
    };
  }

  get totalGSTAmountConfirmed(): number {
    const totals = this.confirmedTotals;
    const total = totals.totalCGST + totals.totalSGST + totals.totalIGST;
    return isNaN(total) ? 0 : total;
  }

  get totalGSTAmountMakeToOrder(): number {
    const totals = this.makeToOrderTotals;
    const total = totals.totalCGST + totals.totalSGST + totals.totalIGST;
    return isNaN(total) ? 0 : total;
  }

  get colspan(): number {
    return this.isIntraState ? 16 : 15;
  }

  // Removal with confirmation from table 2
  async confirmRemoveFromMakeToOrder(index: number) {
  const result = await Swal.fire({
    title: 'Remove this item?',
    text: 'It will be excluded from both POs and processed as cancelled on confirm.',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, remove',
    cancelButtonText: 'Cancel',
    confirmButtonColor: '#007bff',
    cancelButtonColor: '#6c757d'
  });
  if (!result.isConfirmed) return;

  const removed = this.makeToOrderItems.splice(index, 1)[0];
  if (removed) {
    this.removedFromPartial.push(removed);
    this.communicationService.customSuccess('Item queued for cancel and inventory update');
  }
}

  // Navigation
  navigateFun() {
    this.location.back();
  }

  // Date formatting
  getFormattedDate(dateString: string): string {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString();
  }

  // SweetAlert2 Confirmation Dialog (reuse)
  async showConfirmation(action: string): Promise<boolean> {
    let title = '';
    let text = '';

    switch (action) {
      case 'acceptBoth':
        title = 'Generate New PO?';
        text = 'This will update the current PO with available items and create a new Make-to-Order PO for remaining items.';
        break;
      case 'rejectAll':
        title = 'Cancel Entire Order?';
        text = 'This will cancel the complete purchase order after updating inventory.';
        break;
    }

    const result = await Swal.fire({
      title,
      text,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, proceed',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#007bff',
      cancelButtonColor: '#6c757d'
    });

    return result.isConfirmed;
  }

  // Button: Generate New PO (Accept Both flow)
  async onGenerateNewPo() {
    const ok = await this.showConfirmation('acceptBoth');
    if (!ok) return;

    this.isLoading = true;
    try {
      // Build finalRemaining snapshot for downstream usage
      this.finalRemaining = [...this.confirmedItems, ...this.makeToOrderItems];

      // Update current PO with dispatchable quantities
      await this.updatePOWithConfirmedItems();

      // Create make-to-order PO only for items with remainingQuantity > 0
      await this.createMakeToOrderPO();

      this.showSuccessMessage('acceptBoth');

      setTimeout(() => this.navigateFun(), 2000);
    } catch (err) {
      console.error('Generate New PO error:', err);
      this.showErrorMessage('Failed to generate new PO. Please try again.');
    } finally {
      this.isLoading = false;
    }
  }

  // Button: Cancel Order (same logic as Cancel Entire Order)
  async onCancelOrder() {
    const ok = await this.showConfirmation('rejectAll');
    if (!ok) return;

    this.isLoading = true;
    try {
      await this.updateInventoryBulk();
      await this.updatePOStatus('r_order_cancelled');
      this.showSuccessMessage('rejectAll');
      setTimeout(() => this.navigateFun(), 2000);
    } catch (err) {
      console.error('Cancel Order error:', err);
      this.showErrorMessage('Failed to cancel order. Inventory update or order cancellation failed.');
    } finally {
      this.isLoading = false;
    }
  }

  // Success / Error messages
  showSuccessMessage(action: string) {
    let message = '';
    switch (action) {
      case 'acceptBoth':
        message = 'Order Updated and New Make to Order created';
        break;
      case 'rejectAll':
        message = 'Order cancelled successfully';
        break;
    }
    Swal.fire({
      icon: 'success',
      title: 'Success!',
      text: message,
      timer: 2000,
      showConfirmButton: false
    });
  }

  showErrorMessage(message: string) {
    Swal.fire({
      icon: 'error',
      title: 'Error',
      text: message || 'Something went wrong. Please try again.',
      confirmButtonColor: '#007bff'
    });
  }

  // Inventory bulk update (used in cancel flow)
  private async updateInventoryBulk(): Promise<any> {
    const itemsToUpdate = (this.responseData?.set || []).filter((item: any) =>
      item.availableQuantity && Number(item.availableQuantity) > 0
    );

    if (itemsToUpdate.length === 0) {
      return Promise.resolve();
    }

    const manufacturerEmail = this.responseData?.manufacturer?.email;

    const updates = itemsToUpdate.map((item: any) => ({
      designNumber: item.designNumber,
      colourName: item.colourName,
      standardSize: item.size,
      quantity: Number(item.availableQuantity),
      status: 'add',
      lastUpdatedBy: 'Admin',
      userEmail: manufacturerEmail
    }));

    const payload = { updates };

    return this.authService.post('manufacture-inventory/update-bulk', payload)
      .pipe(
        retry(2),
        catchError(error => {
          console.error('Error updating inventory bulk:', error);
          return throwError(() => error);
        })
      ).toPromise();
  }

  // Update PO status
  private updatePOStatus(status: string): Promise<any> {
    const url = `po-retailer-to-manufacture/${this.responseData.id}`;
    const payload = { statusAll: status };

    return this.authService.patchpimage(url, payload)
      .pipe(
        retry(2),
        catchError(error => {
          console.error('Error updating PO status:', error);
          return throwError(() => error);
        })
      ).toPromise();
  }

  // Update PO with dispatchable quantities for current order
  private updatePOWithConfirmedItems(): Promise<any> {
    const url = `po-retailer-to-manufacture/${this.responseData.id}`;

    // For current PO: set quantity to availableQuantity for ALL rows, and keep expectedQty as original
    const updatedSet = (this.responseData?.set || []).map((item: any) => ({
      ...item,
      expectedQty: Number(item.quantity) || 0,
      quantity: Number(item.availableQuantity) || 0
    }));

    const payload = {
      statusAll: 'm_order_confirmed',
      set: updatedSet
    };

    return this.authService.patchpimage(url, payload)
      .pipe(
        retry(2),
        catchError(error => {
          console.error('Error updating PO with confirmed items:', error);
          return throwError(() => error);
        })
      ).toPromise();
  }

  // Create Make-to-Order PO for residuals only
  private createMakeToOrderPO(): Promise<any> {
    const url = `po-retailer-to-manufacture/make-to-order`;

    // Use current makeToOrderItems state and include only rows with remaining > 0
    const makeToOrderSet = (this.makeToOrderItems || [])
      .filter(x => (Number(x.remainingQuantity) || 0) > 0)
      .map(item => ({
        ...item,
        quantity: Number(item.remainingQuantity) || 0,
        availableQuantity: 0,
        confirmed: false,
        rejected: false,
        status: 'make_to_order'
      }));

    if (makeToOrderSet.length === 0) {
      // Nothing to create
      return Promise.resolve();
    }

    const payload = {
      previousPoNumber: this.responseData.poNumber,
      previousPoId: this.responseData.id,
      statusAll: 'make_to_order',
      set: makeToOrderSet,
      manufacturer: this.responseData.manufacturer,
      retailer: this.responseData.retailer,
      transportDetails: this.responseData.transportDetails,
      bankDetails: this.responseData.bankDetails,
      email: this.responseData.email,
      manufacturerEmail: this.responseData.manufacturerEmail,
      discount: this.responseData.discount,
      retailerPoDate: new Date(),
      expDeliveryDate: this.responseData.partialDeliveryDate,
      partialDeliveryDate: this.responseData.partialDeliveryDate
    };

    return this.authService.post(url, payload)
      .pipe(
        retry(2),
        catchError(error => {
          console.error('Error creating make-to-order PO:', error);
          return throwError(() => error);
        })
      ).toPromise();
  }

  // Order Summary Getters
  get totalConfirmedItems(): number {
    return this.confirmedItems.length;
  }

  get totalPendingItems(): number {
    return this.makeToOrderItems.length;
  }

  get expDeliveryDate(): Date | string {
    return this.purchaseOrder.expDeliveryDate || this.responseData?.expDeliveryDate || '';
  }

  get partialDeliveryDate(): Date | string {
    return this.purchaseOrder.partialDeliveryDate || this.responseData?.partialDeliveryDate || '';
  }

  get totalConfirmedAmount(): number {
    const amount = this.confirmedTotals.actualGrandTotal;
    return isNaN(amount) ? 0 : amount;
  }

  get totalPendingAmount(): number {
    const amount = this.makeToOrderTotals.actualGrandTotal;
    return isNaN(amount) ? 0 : amount;
  }

  // New confirm entry-point for preview page “Confirm & Update POs”
// async onConfirmAndUpdatePOs() {
//   const ok = await this.showConfirmation('acceptBoth'); // reuse dialog copy
//   if (!ok) return;

//   this.isLoading = true;
//   try {
//     // 1) Snapshot after all removals (optional)
//     this.finalRemaining = [...this.confirmedItems, ...this.makeToOrderItems];

//     // 2) Update current PO excluding removed rows (mark them r_cancelled with qty 0)
//     await this.updatePOExcludingRemoved();

//     // 3) Create Make-to-Order for remaining items only (removed excluded)
//     await this.createMakeToOrderPOExcludingRemoved();

//     // 4) Return cancelled available quantities back to inventory
//     await this.updateInventoryForRemoved();

//     this.showSuccessMessage('acceptBoth');
//     setTimeout(() => this.navigateFun(), 2000);
//   } catch (e) {
//     console.error('Confirm & Update error:', e);
//     this.showErrorMessage('Failed to confirm updates. Please try again.');
//   } finally {
//     this.isLoading = false;
//   }
// }

// Update current PO: exclude removed lines from active quantities; mark them r_cancelled
private updatePOExcludingRemoved(): Promise<any> {
  const url = `po-retailer-to-manufacture/${this.responseData.id}`;

  const removedIds = new Set((this.removedFromPartial || []).map((x: any) => x._id));
  const originalSet: any[] = this.responseData?.set || [];

  // Build updated set:
  // - Non-removed: expectedQty = original ordered qty, quantity = availableQuantity
  // - Removed: quantity = 0, status = 'r_cancelled' (kept for audit)
  const updatedSet = originalSet.map((item: any) => {
    const expectedQty = Number(item.quantity) || 0;
    const available = Number(item.availableQuantity) || 0;

    if (removedIds.has(item._id)) {
      return {
        ...item,
        expectedQty,
        quantity: 0,
        status: 'r_cancelled'
      };
    }

    return {
      ...item,
      expectedQty,
      quantity: available,
      status: 'm_order_confirmed'
    };
  });

  const payload = {
    statusAll: 'm_order_confirmed',
    set: updatedSet
  };

  return this.authService.patchpimage(url, payload)
    .pipe(
      retry(2),
      catchError(error => {
        console.error('Error updating PO excluding removed:', error);
        return throwError(() => error);
      })
    ).toPromise();
}

// Create Make-to-Order: only rows with remainingQuantity > 0 and NOT removed
private createMakeToOrderPOExcludingRemoved(): Promise<any> {
  const url = `po-retailer-to-manufacture/make-to-order`;

  const removedKey = (x: any) => `${x._id}`;
  const removedSet = new Set((this.removedFromPartial || []).map(removedKey));

  const makeToOrderSet = (this.makeToOrderItems || [])
    .filter(item => !removedSet.has(removedKey(item)))
    .filter(item => (Number(item.remainingQuantity) || 0) > 0)
    .map(item => ({
      ...item,
      quantity: Number(item.remainingQuantity) || 0,
      availableQuantity: 0,
      confirmed: false,
      rejected: false,
      status: 'make_to_order'
    }));

  if (makeToOrderSet.length === 0) {
    return Promise.resolve();
  }

  const payload = {
    previousPoNumber: this.responseData.poNumber,
    previousPoId: this.responseData.id,
    statusAll: 'make_to_order',
    set: makeToOrderSet,
    manufacturer: this.responseData.manufacturer,
    retailer: this.responseData.retailer,
    transportDetails: this.responseData.transportDetails,
    bankDetails: this.responseData.bankDetails,
    email: this.responseData.email,
    manufacturerEmail: this.responseData.manufacturerEmail,
    discount: this.responseData.discount,
    retailerPoDate: new Date(),
    expDeliveryDate: this.responseData.partialDeliveryDate,
    partialDeliveryDate: this.responseData.partialDeliveryDate
  };

  return this.authService.post(url, payload)
    .pipe(
      retry(2),
      catchError(error => {
        console.error('Error creating MTO excluding removed:', error);
        return throwError(() => error);
      })
    ).toPromise();
}

// Inventory update specifically for removed rows:
// add back availableQuantity > 0 to manufacturer inventory
private updateInventoryForRemoved(): Promise<any> {
  const removed = this.removedFromPartial || [];
  const itemsToAdd = removed.filter((x: any) => Number(x.availableQuantity) > 0);

  if (itemsToAdd.length === 0) {
    return Promise.resolve();
  }

  const manufacturerEmail = this.responseData?.manufacturer?.email;
  const updates = itemsToAdd.map((item: any) => ({
    designNumber: item.designNumber,
    colourName: item.colourName,
    standardSize: item.size,
    quantity: Number(item.availableQuantity),
    status: 'add',
    lastUpdatedBy: 'Admin',
    userEmail: manufacturerEmail
  }));

  const payload = { updates };
  return this.authService.post('manufacture-inventory/update-bulk', payload)
    .pipe(
      retry(2),
      catchError(error => {
        console.error('Error updating inventory for removed:', error);
        return throwError(() => error);
      })
    ).toPromise();
}

// Optional separate totals for preview so existing tables remain untouched
get confirmedPreviewTotals() {
  let totalQty = 0, totalTaxable = 0, totalCGST = 0, totalSGST = 0, totalIGST = 0, totalWithGST = 0;
  for (const item of this.previewConfirmedItems) {
    const gst = this.getGstAmounts(item);
    totalQty += Number(item.quantity) || 0;
    totalTaxable += gst.taxable || 0;
    totalCGST += gst.cgst || 0;
    totalSGST += gst.sgst || 0;
    totalIGST += gst.igst || 0;
    totalWithGST += gst.totalWithGst || 0;
  }
  const discountPercent = Number(this.purchaseOrder.ProductDiscount) || 0;
  const discountAmount = (totalWithGST * discountPercent) / 100;
  const actualGrandTotal = totalWithGST - discountAmount;
  return { totalQty, totalTaxable, totalCGST, totalSGST, totalIGST, totalWithGST, discountAmount, actualGrandTotal };
}

get makeToOrderPreviewTotals() {
  let totalQty = 0, totalTaxable = 0, totalCGST = 0, totalSGST = 0, totalIGST = 0, totalWithGST = 0;
  for (const item of this.previewMakeToOrderItems) {
    const gst = this.getGstAmounts(item, true);
    totalQty += Number(item.remainingQuantity) || 0;
    totalTaxable += gst.taxable || 0;
    totalCGST += gst.cgst || 0;
    totalSGST += gst.sgst || 0;
    totalIGST += gst.igst || 0;
    totalWithGST += gst.totalWithGst || 0;
  }
  const discountPercent = Number(this.purchaseOrder.ProductDiscount) || 0;
  const discountAmount = (totalWithGST * discountPercent) / 100;
  const actualGrandTotal = totalWithGST - discountAmount;
  return { totalQty, totalTaxable, totalCGST, totalSGST, totalIGST, totalWithGST, discountAmount, actualGrandTotal };
}

get totalGSTAmountConfirmedPreview(): number {
  const t = this.confirmedPreviewTotals;
  return (t.totalCGST + t.totalSGST + t.totalIGST) || 0;
}

get totalGSTAmountMakeToOrderPreview(): number {
  const t = this.makeToOrderPreviewTotals;
  return (t.totalCGST + t.totalSGST + t.totalIGST) || 0;
}

// Build preview arrays and open overlay
openPreview() {
  const removedIds = new Set((this.removedFromPartial || []).map((x: any) => x._id));

  // Confirmed PO preview:
  // - include all current confirmedItems as-is
  // - include non-removed rows from makeToOrderItems with their available (quantity already set)
  const confirmedFromPartial = (this.makeToOrderItems || [])
    .filter(x => !removedIds.has(x._id))
    .map(x => ({
      ...x,
      // ensure dispatch quantity is the available part
      quantity: Number(x.availableQuantity ?? x.quantity) || 0,
      expectedQty: Number(x.expectedQty ?? x.quantity) || 0
    }));

  this.previewConfirmedItems = [
    ...(this.confirmedItems || []),
    ...confirmedFromPartial
  ];

  // Make-to-Order PO preview: only non-removed rows with remainingQuantity > 0
  this.previewMakeToOrderItems = (this.makeToOrderItems || [])
    .filter(x => !removedIds.has(x._id))
    .filter(x => (Number(x.remainingQuantity) || 0) > 0);

  this.showPreview = true;
}

// Replace the body of onConfirmAndUpdatePOs to open preview first
async onConfirmAndUpdatePOs() {
  // Optional: gate with a light confirmation before preview
  const ok = await this.showConfirmation('acceptBoth');
  if (!ok) return;
  this.openPreview();
}

// Add a finalize method invoked from the preview Confirm button
async finalizeConfirmAndUpdatePOs() {
  this.isLoading = true;
  try {
    // Snapshot for audit if needed
    this.finalRemaining = [...this.previewConfirmedItems, ...this.previewMakeToOrderItems];

    // Proceed with existing backend updates excluding removed rows
    await this.updatePOExcludingRemoved();
    await this.createMakeToOrderPOExcludingRemoved();
    await this.updateInventoryForRemoved();

    this.showSuccessMessage('acceptBoth');
    setTimeout(() => this.navigateFun(), 2000);
  } catch (e) {
    console.error('Confirm & Update error:', e);
    this.showErrorMessage('Failed to confirm updates. Please try again.');
  } finally {
    this.isLoading = false;
    this.showPreview = false;
  }
}

// Allow closing preview without submitting
closePreview() {
  this.showPreview = false;
}

}
