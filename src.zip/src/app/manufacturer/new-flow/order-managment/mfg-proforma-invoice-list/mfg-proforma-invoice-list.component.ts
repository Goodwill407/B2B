// <!-- Manufacture Retailer Invoice List -->

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { AuthService, CommunicationService } from '@core';
import { PaginatorModule } from 'primeng/paginator';
import { TableModule } from 'primeng/table';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-mfg-proforma-invoice-list',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    PaginatorModule,
    RouterModule,
  ],
  templateUrl: './mfg-proforma-invoice-list.component.html',
  styleUrl: './mfg-proforma-invoice-list.component.scss'
})
export class MfgProformaInvoiceListComponent implements OnInit {

  proformaList: any[] = []; // Array to hold the list of invoices
  first: number = 0;  // For pagination
  rows: number = 10;  // For pagination
  totalResults: number = 0;  // Total number of results for pagination
  loading: boolean = false; // Loading state
  currentPage: number = 1; // Current page number

  constructor(
    private route: ActivatedRoute,
    private authService: AuthService,
    private communicationService: CommunicationService
  ) { }

  ngOnInit(): void {
    this.getMfgInvoices();
  }

  getMfgInvoices() {
    this.loading = true;

    // Updated API endpoint with proper parameters and sorting
    const manufacturerEmail = this.authService.currentUserValue.email;
    this.currentPage = Math.floor(this.first / this.rows) + 1;

    const url = `pi-manufacture-to-retailer?manufacturerEmail=${manufacturerEmail}&page=${this.currentPage}&limit=${this.rows}&sortBy=createdAt:desc`;

    this.authService.get(url).subscribe(
      (res: any) => {
        this.proformaList = res.results || [];  // Based on actual response structure
        this.totalResults = res.totalResults || 0; // Based on actual response structure
        this.loading = false;
        console.log('Invoice List:', this.proformaList);
        console.log('Total Results:', this.totalResults);
      },
      (error) => {
        console.error('Error fetching invoices:', error);
        this.loading = false;
        this.communicationService.customError1('Failed to load invoices');
      }
    );
  }

  onPageChange(event: any) {
    this.first = event.first;
    this.rows = event.rows;
    this.getMfgInvoices();
  }
}
