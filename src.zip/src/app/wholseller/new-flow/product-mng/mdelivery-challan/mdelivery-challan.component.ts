import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatTabsModule } from '@angular/material/tabs';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService, CommunicationService } from '@core';
import html2canvas from 'html2canvas';
import { PaginatorModule } from 'primeng/paginator';
import { TableModule } from 'primeng/table';
import { TooltipModule } from 'primeng/tooltip';
import jsPDF from 'jspdf';
import {  RouterModule } from '@angular/router';
import { BottomSideAdvertiseComponent } from '@core/models/advertisement/bottom-side-advertise/bottom-side-advertise.component';
@Component({
  selector: 'app-mdelivery-challan',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    CommonModule,
    PaginatorModule,
    TooltipModule,
    TableModule,
    MatTabsModule,
    RouterModule,
    BottomSideAdvertiseComponent
  ],
  templateUrl: './mdelivery-challan.component.html',
  styleUrl: './mdelivery-challan.component.scss'
})
export class MdeliveryChallanComponent {
  purchaseOrder: any = {
    supplierName: '',
    supplierDetails: '',
    supplierAddress: '',
    supplierContact: '',
    supplierGSTIN: '',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/3/38/MONOGRAM_LOGO_Color_200x200_v.png',
    orderNo: 'PO123',
    orderDate: new Date().toLocaleDateString(),
    deliveryDate: '',
    buyerName: '',
    buyerAddress: '',
    buyerPhone: '',
    buyerGSTIN: '',
    products: [],
    totalAmount: 0,
    totalInWords: ''
  };
  email: string | null = null;
  productBy: string | null = null;
  userProfile: any;
  showFlag: boolean = false;
  tableData: any;
  tableData2: any;
  tableData4: any;
  tableData3: any;
  totalResults: any;
  totalResults2: any;
  limit = 10;
  page: number = 1
  first: number = 0;
  rows: number = 10;
  isNewPO: boolean = false;
  totalResults3: any;
  totalResults4: any;
  bottomAdImage: string[] = [
    'assets/images/adv/ads2.jpg',
  'assets/images/adv/ads.jpg'
  ];


  constructor(private route: ActivatedRoute, private authService: AuthService, private communicationService: CommunicationService) { }

  ngOnInit(): void {
    this.route.queryParamMap.subscribe(params => {
      this.userProfile = JSON.parse(localStorage.getItem('currentUser')!);
      this.userProfile.email

  
        this.getAllData();
        this.getAllData2();
        this.getAllData3();
        this.getAllData4();
    });
  }

  getAllData() {
    this.showFlag = false;
    this.authService.get(`/mnf-delivery-challan?email=${this.authService.currentUserValue.email}&status=proceed&page=${this.page}&limit=${this.limit}`).subscribe((res: any) => {
      this.tableData = res.results;
      console.log(res)
      this.totalResults = res.totalResults;
    })
  }
  getAllData2() {
    this.showFlag = false;
    this.authService.get(`/mnf-delivery-challan?email=${this.authService.currentUserValue.email}&status=Pending&page=${this.page}&limit=${this.limit}`).subscribe((res: any) => {
      this.tableData2 = res.results;
      console.log(res)
      this.totalResults2 = res.totalResults;
    })
  }
  getAllData3() {
    this.showFlag = false;
    this.authService.get(`/mnf-delivery-challan?email=${this.authService.currentUserValue.email}&status=Forwarded&page=${this.page}&limit=${this.limit}`).subscribe((res: any) => {
      this.tableData3 = res.results;
      console.log(res)
      this.totalResults3 = res.totalResults;
    })
  }
  getAllData4() {
    this.showFlag = false;
    this.authService.get(`/mnf-delivery-challan?email=${this.authService.currentUserValue.email}&status=Rejected&page=${this.page}&limit=${this.limit}`).subscribe((res: any) => {
      this.tableData4 = res.results;
      console.log(res)
      this.totalResults4 = res.totalResults;
    })
  }
  patchData(data: any) {
    this.purchaseOrder = data;
    this.isNewPO = false;  // Set to false to hide the "Generate PO" button
    this.showFlag = true;  // Show the purchase order details
  }

  generatePO(obj: any) {
    this.authService.post('product-order', obj).subscribe((res: any) => {
      this.communicationService.showNotification('snackbar-success', 'PO Generated Successfully .. !', 'bottom', 'center');
      this.getAllData();
      this.isNewPO = false;  // After generating, ensure the button is hidden
    });
  }

  onPageChange(event: any) {
    this.page = event.page + 1;
    this.limit = event.rows;
    this.getAllData();
  }

  convertNumberToWords(amount: number): string {
    const units = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"];
    const teens = ["Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
    const tens = ["", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
    const thousands = ["", "Thousand", "Million", "Billion"];

    if (amount === 0) return "Zero";

    let words = '';

    function numberToWords(num: number, index: number): string {
      let str = '';
      if (num > 99) {
        str += units[Math.floor(num / 100)] + " Hundred ";
        num %= 100;
      }
      if (num > 10 && num < 20) {
        str += teens[num - 11] + " ";
      } else {
        str += tens[Math.floor(num / 10)] + " ";
        str += units[num % 10] + " ";
      }
      if (str.trim().length > 0) {
        str += thousands[index] + " ";
      }
      return str;
    }

    let i = 0;
    while (amount > 0) {
      words = numberToWords(amount % 1000, i) + words;
      amount = Math.floor(amount / 1000);
      i++;
    }

    return words.trim();
  }


  printPurchaseOrder(): void {
    const data = document.getElementById('purchase-order');
    if (data) {
      html2canvas(data, {
        scale: 3,  // Adjust scale for better quality
        useCORS: true,
      }).then((canvas) => {
        const imgWidth = 208;  // A4 page width in mm
        const pageHeight = 295;  // A4 page height in mm
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        let heightLeft = imgHeight;
  
        const contentDataURL = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');  // Create new PDF
        const margin = 10;  // Margin for PDF
        let position = margin;
  
        // Add first page
        pdf.addImage(contentDataURL, 'PNG', margin, position, imgWidth - 2 * margin, imgHeight);
        heightLeft -= pageHeight;
  
        // Loop over content to add remaining pages if content exceeds one page
        while (heightLeft > 0) {
          pdf.addPage();  // Add new page
          position = margin - heightLeft;  // Position for the next page
          pdf.addImage(contentDataURL, 'PNG', margin, position, imgWidth - 2 * margin, imgHeight);
          heightLeft -= pageHeight;
        }
  
        // Save PDF file
        pdf.save('purchase-order.pdf');
      }).catch((error) => {
        console.error("Error generating PDF:", error);
      });
    } else {
      console.error("Element with id 'purchase-order' not found.");
    }
  }
  
}
