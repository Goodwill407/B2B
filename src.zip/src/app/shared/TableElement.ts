export interface TableElement {
  [key: string]: string | number;
}
