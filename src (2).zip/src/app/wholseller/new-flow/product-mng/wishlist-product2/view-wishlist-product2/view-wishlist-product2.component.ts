import { Component } from '@angular/core';

@Component({
  selector: 'app-view-wishlist-product2',
  standalone: true,
  imports: [],
  templateUrl: './view-wishlist-product2.component.html',
  styleUrl: './view-wishlist-product2.component.scss'
})
export class ViewWishlistProduct2Component {

}
