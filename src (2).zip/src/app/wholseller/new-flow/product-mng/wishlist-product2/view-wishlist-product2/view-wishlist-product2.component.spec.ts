import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewWishlistProduct2Component } from './view-wishlist-product2.component';

describe('ViewWishlistProduct2Component', () => {
  let component: ViewWishlistProduct2Component;
  let fixture: ComponentFixture<ViewWishlistProduct2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewWishlistProduct2Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ViewWishlistProduct2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
