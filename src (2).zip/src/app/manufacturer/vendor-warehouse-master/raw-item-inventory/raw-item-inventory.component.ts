import { Component } from '@angular/core';

@Component({
  selector: 'app-raw-item-inventory',
  standalone: true,
  imports: [],
  templateUrl: './raw-item-inventory.component.html',
  styleUrl: './raw-item-inventory.component.scss'
})
export class RawItemInventoryComponent {

}
